package cm.siplus2018.tradex;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import cm.siplus2018.tradex.utils.Util;

public class RouteTrace extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnPolylineClickListener, GoogleMap.OnPolygonClickListener{

    private SupportMapFragment mapFragment;
    private GoogleMap mGoogleMap;
    private double origin_latitude, origin_longitude, destination_latitude, destination_longitude;
    private Polyline polyline;
    private String stationname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_trace);

        Bundle bundle = getIntent().getExtras();

        origin_latitude = bundle.getDouble("origin_latitude");
        origin_longitude = bundle.getDouble("origin_longitude");
        destination_latitude = bundle.getDouble("destination_latitude");
        destination_longitude = bundle.getDouble("destination_longitude");
        stationname = bundle.getString("stationname");

        Log.e("data", stationname + ", " + origin_latitude + ", " + origin_longitude + ", " + destination_latitude + ", " + destination_longitude);


        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.route_map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        LatLng latLng = new LatLng(origin_latitude, origin_longitude);
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Ma position");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN));
        Marker marker = mGoogleMap.addMarker(markerOptions);

        LatLng latLngDestination = new LatLng(destination_latitude, destination_longitude);
        MarkerOptions markerOptionsdestination = new MarkerOptions();
        markerOptionsdestination.position(latLngDestination);
        markerOptionsdestination.title(stationname);
        markerOptionsdestination.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
        Marker markerdestination = mGoogleMap.addMarker(markerOptionsdestination);


        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,12.5f));

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.e("PERMISSION PERMISSION " , "PERMISSION PERMISSION PERMISSION PERMISSION PERMISSION PERMISSION");
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mGoogleMap.setMyLocationEnabled(true);        /*// Add polylines and polygons to the map. This section shows just
        // a single polyline. Read the rest of the tutorial to learn more.
        Polyline polyline1 = googleMap.addPolyline(new PolylineOptions()
                .clickable(true)
                .add(
                        new LatLng(-35.016, 143.321),
                        new LatLng(-34.747, 145.592),
                        new LatLng(-34.364, 147.891),
                        new LatLng(-33.501, 150.217),
                        new LatLng(-32.306, 149.248),
                        new LatLng(-32.491, 147.309)));

        // Position the map's camera near Alice Springs in the center of Australia,
        // and set the zoom factor so most of Australia shows on the screen.
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(-23.684, 133.903), 4));*/

        // Set listeners for click events.
        googleMap.setOnPolylineClickListener(this);
        googleMap.setOnPolygonClickListener(this);


        (new PathGetter()).execute();
    }

    @Override
    public void onPolygonClick(Polygon polygon) {

    }

    @Override
    public void onPolylineClick(Polyline polyline) {

    }

    public String makeURL(double sourcelat, double sourcelog, double destlat, double destlog) {
        String urlString = "";
        urlString += Util.DIRECTION_URL;
        urlString +="?origin=";// from
        urlString += Double.toString(sourcelat);
        urlString += ",";
        urlString += Double.toString(sourcelog);
        urlString += "&destination=";// to
        urlString += Double.toString(destlat);
        urlString += ",";
        urlString += Double.toString(destlog);
        urlString += "&mode=driving&alternatives=true";
        urlString += "&key=" + "AIzaSyCmwfuYybnZ7st5P1VmJ4q3IAhpE0ei9t8" + "&sensor=true";

        Log.e("URL_DIRECTION", urlString);
        return urlString;
    }

    private class PathGetter extends AsyncTask<String,Integer, String> {
        private ProgressBar dialog;
        private String string_certificate = null;
        public PathGetter() {
            dialog = findViewById(R.id.pathloader);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.dialog.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... strings) {

            //String lat = strings[0], log = strings[1];
            //double dlat = Double.parseDouble(lat), dlog = Double.parseDouble(log);
            String resultat = "";
            URL url = null;
            try {
                url = new URL(makeURL(origin_latitude, origin_longitude, destination_latitude, destination_longitude));
                HttpsURLConnection urlConnection;
                try {
                    urlConnection = (HttpsURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    InputStream in = urlConnection.getInputStream();

                    BufferedReader br = null;
                    StringBuilder sb = new StringBuilder();
                    String line;
                    try {
                        br = new BufferedReader(new InputStreamReader(in));
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }

                    } catch (IOException e) {
                        return e.getMessage();
                    } finally {
                        if (br != null) {
                            try {
                                br.close();
                            } catch (IOException e) {
                                return e.getMessage();
                            }
                        }
                    }
                    in.close();
                    //os.close();
                    resultat = sb.toString();

                } catch (IOException e) {
                    return e.getMessage() ;
                }
            } catch (MalformedURLException e) {
                return e.getMessage();
            } /*catch (IOException e) {
                e.printStackTrace();
            }*/

            return resultat;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute( result);
            if (dialog.getVisibility() == View.VISIBLE) {
                dialog.setVisibility(View.GONE);
            }

            //Log.e("DIRECTION RESULT" , result);
            //Toast.makeText(getApplicationContext(), "Result: " + result , Toast.LENGTH_LONG).show();
            if(polyline != null) {
                polyline.remove();

            }
            //if (destinationMarker != null) destinationMarker.remove();
            drawPath(result);

        }
    }

    public void drawPath(String  result) {
        try {

            //Tranform the string into a json object
            final JSONObject json = new JSONObject(result);
            JSONArray routeArray = json.getJSONArray("routes");

            for (int i = 0; i<routeArray.length(); i++){
                JSONObject route_i = routeArray.getJSONObject(i);
                JSONObject overviewPolylines = route_i.getJSONObject("overview_polyline");
                String encodedString = overviewPolylines.getString("points");
                List<LatLng> list = decodePoly(encodedString);

                polyline = mGoogleMap.addPolyline(new PolylineOptions()
                        .addAll(list)
                        .clickable(true)
                        .width(12)
                        // .color(Color.parseColor("#00FF00"))//Google maps blue color
                        .color(Color.parseColor("#B01C2E"))//Google maps blue color
                        .geodesic(true)
                );
            }



           /*
           for(int z = 0; z<list.size()-1;z++){
                LatLng src= list.get(z);
                LatLng dest= list.get(z+1);
                Polyline line = mMap.addPolyline(new PolylineOptions()
                .add(new LatLng(src.latitude, src.longitude), new LatLng(dest.latitude,   dest.longitude))
                .width(2)
                .color(Color.BLUE).geodesic(true));
            }
           */
        }
        catch (JSONException e) {

        }
    }

    private List<LatLng> decodePoly(String encoded) {
        //Toast.makeText(getApplicationContext(), "encodedString: " + encoded , Toast.LENGTH_LONG).show();
        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng( (((double) lat / 1E5)),
                    (((double) lng / 1E5) ));
            poly.add(p);
        }

        return poly;
    }

}
