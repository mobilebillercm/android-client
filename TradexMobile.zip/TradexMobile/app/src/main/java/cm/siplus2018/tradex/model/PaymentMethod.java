package cm.siplus2018.tradex.model;

/**
 * Created by nkalla on 14/12/18.
 */

public class PaymentMethod {
    private int id;
    private String paymentmethodid, name, description, issuer, logopath, type, typeName, typeDescription;

    public PaymentMethod(int id, String paymentmethodid, String name, String description, String issuer, String logopath, String type, String typeName, String typeDescription) {
        this.id = id;
        this.paymentmethodid = paymentmethodid;
        this.name = name;
        this.description = description;
        this.issuer = issuer;
        this.logopath = logopath;
        this.type = type;
        this.typeName = typeName;
        this.typeDescription = typeDescription;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPaymentmethodid() {
        return paymentmethodid;
    }

    public void setPaymentmethodid(String paymentmethodid) {
        this.paymentmethodid = paymentmethodid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getLogopath() {
        return logopath;
    }

    public void setLogopath(String logopath) {
        this.logopath = logopath;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getTypeDescription() {
        return typeDescription;
    }

    public void setTypeDescription(String typeDescription) {
        this.typeDescription = typeDescription;
    }
}
