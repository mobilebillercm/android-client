package cm.siplus2018.tradex;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cm.siplus2018.tradex.adapter.StationAdapter;
import cm.siplus2018.tradex.model.Station;
import cm.siplus2018.tradex.utils.Util;

public class StationListByPaymentMethod extends AppCompatActivity {

    private Toolbar toolbar;
    private ListView stations_list;
    private StationAdapter stationAdapter;
    private Bundle extrat;
    private ProgressBar stationsloader;
    private List<Station> stations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_station_list_by_payment_method);

        extrat = getIntent().getExtras();
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.station_list) + " ("  + extrat.getString("name") + ")");
        stationsloader = findViewById(R.id.stationsloader);

        stations_list = findViewById(R.id.stations_list);



        String url = Util.BASE_URL + "stations-paymentmethods/" +  extrat.getString("paymentmethodid");
        stationsloader.setVisibility(View.VISIBLE);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("response");
                    stations = new ArrayList<>();

                    for (int i = 0; i<jsonArray.length(); i++){
                        try {
                            JSONObject stationJson = jsonArray.getJSONObject(i);
                            Station station = new Station(
                                    stationJson.getInt("id"),
                                    stationJson.getString("stationid"),
                                    stationJson.getString("name"),
                                    stationJson.getString("description"),
                                    stationJson.getString("region"),
                                    stationJson.getString("division"),
                                    stationJson.getString("subdivision"),
                                    stationJson.getString("quarter"),
                                    stationJson.getDouble("latitude"),
                                    stationJson.getDouble("longitude"), null
                            );
                            stations.add(station);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    stationAdapter = new StationAdapter(StationListByPaymentMethod.this, stations);
                    stations_list.setAdapter(stationAdapter);
                    stationAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                stationsloader.setVisibility(View.GONE);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                stationsloader.setVisibility(View.GONE);
            }
        });

// Access the RequestQueue through your singleton class.
        ImgController.getInstance().addToRequestQueue(jsonObjectRequest);



        /*stationAdapter = new StationAdapter(this, Util.stations);
        stations_list.setAdapter(stationAdapter);*/
        stations_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Station station = stations.get(position);
                Intent intent = new Intent(getApplicationContext(), StationDetailActivity.class);
                intent.putExtra("id", station.getId());
                intent.putExtra("stationid", station.getStationid());
                intent.putExtra("name", station.getName());
                intent.putExtra("latitude", station.getLatitude());
                intent.putExtra("longitude", station.getLongitude());
                startActivity(intent);
            }
        });
    }

}
