package cm.siplus2018.tradex.model;

public class Service {
    private int id;
    private String serviceid, name, description, logopath;
    private double price;

    public Service(int id, String serviceid, String name, String description, String logopath, double price) {
        this.id = id;
        this.serviceid = serviceid;
        this.name = name;
        this.description = description;
        this.logopath = logopath;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getServiceid() {
        return serviceid;
    }

    public void setServiceid(String serviceid) {
        this.serviceid = serviceid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLogopath() {
        return logopath;
    }

    public void setLogopath(String logopath) {
        this.logopath = logopath;
    }

    @Override
    public String toString() {
        return  name;
    }
}
