package cm.siplus2018.tradex;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cm.siplus2018.tradex.adapter.ServiceAdapter;
import cm.siplus2018.tradex.adapter.SpinnerAdapterServiceName;
import cm.siplus2018.tradex.model.Service;
import cm.siplus2018.tradex.utils.Util;
import cm.siplus2018.tradex.view.CustomAutoCompleteView;

public class ServicesList extends AppCompatActivity {

    private Toolbar toolbar;
    private ListView service_list;
    private ServiceAdapter serviceAdapter;
    private List<Service> services;

    private SpinnerAdapterServiceName spinnerAdapterServiceName;
    private List<Service> listeSecondaireService;
    private Service selectedService;
    private CustomAutoCompleteView editsearch;
    private ProgressBar service_loader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services_list);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.service_list));

        service_list = findViewById(R.id.service_list);

        service_loader = findViewById(R.id.service_loader);

        service_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedService = services.get(position);
                Intent intent = new Intent(getApplicationContext(), StationListByService.class);
                intent.putExtra("serviceid", selectedService.getServiceid());
                intent.putExtra("name", selectedService.getName());
                intent.putExtra("description", selectedService.getDescription());
                Log.e("result-1", "\n\n" + selectedService.getName() + "\n\n");
                startActivity(intent);
            }
        });

        spinnerAdapterServiceName = new SpinnerAdapterServiceName(this, services);
        spinnerAdapterServiceName.setDropDownViewResource(R.layout.custom_item_spinner_service_name);

        editsearch = findViewById(R.id.editsearch);

        editsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                spinnerAdapterServiceName.notifyDataSetChanged();

                listeSecondaireService = new ArrayList<Service>();
                String userInput = s.toString();
                if (services != null){
                    for (Service service : services) {
                        if (service.getName().toUpperCase().contains(s.toString().toUpperCase()) ||
                                service.getName().toLowerCase().contains(s.toString().toLowerCase())) {
                            listeSecondaireService.add(service);
                        }
                    }
                }

                if (listeSecondaireService.size() > 0)
                    selectedService = listeSecondaireService.get(0);
                else selectedService = null;
                spinnerAdapterServiceName =
                        new SpinnerAdapterServiceName(ServicesList.this, listeSecondaireService);
                editsearch.setAdapter(spinnerAdapterServiceName);

                /*if (listeSecondaireService.size() == 1) {
                    Intent intent = new Intent(getApplicationContext(), StationListByService.class);
                    intent.putExtra("serviceid", selectedService.getServiceid());
                    intent.putExtra("name", selectedService.getName());
                    intent.putExtra("description", selectedService.getDescription());
                    Log.e("result0", "\n\n" + selectedService.getName() + "\n\n");
                    startActivity(intent);
                }*/

            }
        });

        editsearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (listeSecondaireService.size() > 0) {
                    //position = 0;
                    Service service = (Service) spinnerAdapterServiceName.getItem(position);//listeSecondaireCentreVote.get(position);
                    String sss = service.getName();
                    Log.e("result", "\n\n" + sss + "\n\n");
                    //spinnerCentreVote.setText(sss);
                    //Toast.makeText(getApplicationContext(), c.getCentre_vote_name()+ "__" +c.getId(),Toast.LENGTH_LONG).show();
                    View v = getCurrentFocus();
                    if (v != null) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    }
                    selectedService = service;
                    Intent intent = new Intent(getApplicationContext(), StationListByService.class);
                    intent.putExtra("serviceid", selectedService.getServiceid());
                    intent.putExtra("name", selectedService.getName());
                    intent.putExtra("description", selectedService.getDescription());
                    startActivity(intent);

                }
            }
        });

        editsearch.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.e("SELECTED", services.get(position).getName());
                Service service = (Service) spinnerAdapterServiceName.getItem(position);//listeSecondaireCentreVote.get(position);
                selectedService = service;
                Intent intent = new Intent(getApplicationContext(), StationListByService.class);
                intent.putExtra("serviceid", selectedService.getServiceid());
                intent.putExtra("name", selectedService.getName());
                intent.putExtra("description", selectedService.getDescription());
                startActivity(intent);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        String url = Util.BASE_URL + "services";
        service_loader.setVisibility(View.VISIBLE);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("response");
                    services = new ArrayList<>();

                    for (int i = 0; i<jsonArray.length(); i++){
                        try {
                            JSONObject serviceJson = jsonArray.getJSONObject(i);
                            Service service = new Service(
                                    serviceJson.getInt("id"),
                                    serviceJson.getString("serviceid"),
                                    serviceJson.getString("name"),
                                    serviceJson.getString("description"),
                                    serviceJson.getString("logo"),
                                    serviceJson.getDouble("price")
                            );
                            services.add(service);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    serviceAdapter = new ServiceAdapter(ServicesList.this, services);
                    service_list.setAdapter(serviceAdapter);
                    serviceAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                service_loader.setVisibility(View.GONE);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                service_loader.setVisibility(View.GONE);
            }
        });

// Access the RequestQueue through your singleton class.
        ImgController.getInstance().addToRequestQueue(jsonObjectRequest);




        /*services = Util.getServices();
        serviceAdapter = new ServiceAdapter(this, services);
        service_list.setAdapter(serviceAdapter);*/
    }
}
