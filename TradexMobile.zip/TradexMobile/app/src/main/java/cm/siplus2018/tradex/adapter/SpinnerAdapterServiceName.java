package cm.siplus2018.tradex.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import cm.siplus2018.tradex.R;
import cm.siplus2018.tradex.model.Service;

public class SpinnerAdapterServiceName extends ArrayAdapter {

    private Context context;
    private List<Service> values;

    public SpinnerAdapterServiceName(Context context, List<Service> values) {
        super(context, R.layout.custom_item_spinner_service_name, values);
        this.context = context;
        this.values = values;
    }

    @Override
    public int getCount() {
        return values.size();
    }

    @Override
    public Object getItem(int position) {
        return values.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position+1;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater li=(LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=li.inflate(R.layout.custom_item_spinner_service_name, null);
        }

        TextView textView_name = (TextView)convertView.findViewById(R.id.save_position_service_name);
        textView_name.setText(values.get(position).getName());

        return convertView;
    }
}
