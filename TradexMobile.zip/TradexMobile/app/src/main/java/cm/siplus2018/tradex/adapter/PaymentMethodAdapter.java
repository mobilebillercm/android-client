package cm.siplus2018.tradex.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.android.volley.toolbox.NetworkImageView;

import java.util.List;

import cm.siplus2018.tradex.ImgController;
import cm.siplus2018.tradex.R;
import cm.siplus2018.tradex.model.PaymentMethod;
import cm.siplus2018.tradex.utils.Util;

/**
 * Created by nkalla on 14/12/18.
 */

public class PaymentMethodAdapter extends BaseAdapter{
    private Context context;
    private List<PaymentMethod> values;

    public PaymentMethodAdapter(Context context, List<PaymentMethod> values) {
        this.context = context;
        this.values = values;
    }

    @Override
    public int getCount() {
        return values.size();
    }

    @Override
    public Object getItem(int position) {
        return values.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater li=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=li.inflate(R.layout.payment_methode_item_layout, null);
        }
        PaymentMethod paymentMethod = values.get(position);

        TextView name = convertView.findViewById(R.id.name);
        name.setText(paymentMethod.getName());

        TextView description = convertView.findViewById(R.id.description);
        description.setText(" " + paymentMethod.getDescription());

        TextView issuer = convertView.findViewById(R.id.issuer);
        issuer.setText( " " + paymentMethod.getIssuer());

        NetworkImageView imageView = convertView.findViewById(R.id.logo);
        imageView.setDefaultImageResId(R.drawable.loader_voley);
        imageView.setImageUrl(Util.BASE_URL + "paymentmethods/" + paymentMethod.getPaymentmethodid() + "/logo", ImgController.getInstance().getImageLoader());

        return convertView;
    }
}
