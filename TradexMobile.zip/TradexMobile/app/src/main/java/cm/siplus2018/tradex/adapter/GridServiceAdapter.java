package cm.siplus2018.tradex.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

import java.util.List;

import cm.siplus2018.tradex.R;
import cm.siplus2018.tradex.model.Service;
import cm.siplus2018.tradex.utils.Util;

/**
 * Created by nkalla on 02/11/18.
 */

public class GridServiceAdapter extends BaseAdapter{
    private Context context;
    private List<Service> services;

    public GridServiceAdapter(Context context, List<Service> services) {
        this.context = context;
        this.services = services;
    }

    @Override
    public int getCount() {
        return services.size();
    }

    @Override
    public Object getItem(int position) {
        return services.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater li=(LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=li.inflate(R.layout.service_item_layout, null);
        }

        TextView service_name = convertView.findViewById(R.id.service_name);
        service_name.setText(services.get(position).getName());
        TextView service_price = convertView.findViewById(R.id.service_price);
        service_price.setText(" " + services.get(position).getPrice());

        final ImageView logo = convertView.findViewById(R.id.service_logo);


        // Instantiate the RequestQueue.
        String url = Util.BASE_URL + "services/" + services.get(position).getServiceid() + "/logo";

        RequestQueue requestQueue = Volley.newRequestQueue(context);

        // Initialize a new ImageRequest
        ImageRequest imageRequest = new ImageRequest(
                url, // Image URL
                new Response.Listener<Bitmap>() { // Bitmap listener
                    @Override
                    public void onResponse(Bitmap response) {
                        // Do something with response
                        logo.setImageBitmap(response);

                        // Save this downloaded bitmap to internal storage
                        //Uri uri = saveImageToInternalStorage(response);

                        // Display the internal storage saved image to image view
                        //mImageViewInternal.setImageURI(uri);
                    }
                },
                0, // Image width
                0, // Image height
                ImageView.ScaleType.CENTER_CROP, // Image scale type
                Bitmap.Config.RGB_565, //Image decode configuration
                new Response.ErrorListener() { // Error listener
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Do something with error response
                        error.printStackTrace();
                       // Snackbar.make(mCLayout,"Error",Snackbar.LENGTH_LONG).show();
                    }
                }
        );

        // Add ImageRequest to the RequestQueue
        requestQueue.add(imageRequest);



        return convertView;
    }
}
