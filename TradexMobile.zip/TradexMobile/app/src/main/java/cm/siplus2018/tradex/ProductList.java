package cm.siplus2018.tradex;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cm.siplus2018.tradex.adapter.ProductAdapter;
import cm.siplus2018.tradex.adapter.SpinnerAdapterProductName;
import cm.siplus2018.tradex.model.Product;
import cm.siplus2018.tradex.utils.Util;
import cm.siplus2018.tradex.view.CustomAutoCompleteView;

public class ProductList extends AppCompatActivity {

    private Toolbar toolbar;
    private ListView product_list;
    private ProductAdapter productAdapter;
    private List<Product> products;

    private SpinnerAdapterProductName spinnerAdapterProductName;
    private List<Product> listeSecondaireProduct;
    private Product selectedProduct;
    private CustomAutoCompleteView editsearch;
    private ProgressBar product_loader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.product_list));

        product_list = findViewById(R.id.product_list);
        product_loader = findViewById(R.id.product_loader);

        product_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedProduct = products.get(position);
                Intent intent = new Intent(getApplicationContext(), StationListByProduct.class);
                intent.putExtra("productid", selectedProduct.getProductid());
                intent.putExtra("name", selectedProduct.getName());
                intent.putExtra("description", selectedProduct.getDescription());
                Log.e("result-1", "\n\n" + selectedProduct.getName() + "\n\n");
                startActivity(intent);
            }
        });

        spinnerAdapterProductName = new SpinnerAdapterProductName(this, products);
        spinnerAdapterProductName.setDropDownViewResource(R.layout.custom_item_spinner_product_name);

        editsearch = findViewById(R.id.editsearch);

        editsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                spinnerAdapterProductName.notifyDataSetChanged();

                listeSecondaireProduct = new ArrayList<Product>();
                String userInput = s.toString();
                if (products != null){
                    for (Product product : products) {

                        if (product.getName().toUpperCase().contains(s.toString().toUpperCase()) ||
                                product.getName().toLowerCase().contains(s.toString().toLowerCase())) {
                            listeSecondaireProduct.add(product);
                        }
                    }
                }

                if (listeSecondaireProduct.size() > 0)
                    selectedProduct = listeSecondaireProduct.get(0);
                else selectedProduct = null;
                spinnerAdapterProductName =
                        new SpinnerAdapterProductName(ProductList.this, listeSecondaireProduct);
                editsearch.setAdapter(spinnerAdapterProductName);

                /*if (listeSecondaireProduct.size() == 1) {
                    Intent intent = new Intent(getApplicationContext(), StationListByProduct.class);
                    intent.putExtra("productid", selectedProduct.getProductid());
                    intent.putExtra("name", selectedProduct.getName());
                    intent.putExtra("description", selectedProduct.getDescription());
                    Log.e("result0", "\n\n" + selectedProduct.getName() + "\n\n");
                    startActivity(intent);
                }*/

            }
        });

        editsearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (listeSecondaireProduct.size() > 0) {
                    //position = 0;
                    Product product = (Product) spinnerAdapterProductName.getItem(position);//listeSecondaireCentreVote.get(position);
                    String sss = product.getName();
                    Log.e("result", "\n\n" + sss + "\n\n");
                    //spinnerCentreVote.setText(sss);
                    //Toast.makeText(getApplicationContext(), c.getCentre_vote_name()+ "__" +c.getId(),Toast.LENGTH_LONG).show();
                    View v = getCurrentFocus();
                    if (v != null) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    }
                    selectedProduct = product;
                    Intent intent = new Intent(getApplicationContext(), StationListByProduct.class);
                    intent.putExtra("productid", selectedProduct.getProductid());
                    intent.putExtra("name", selectedProduct.getName());
                    intent.putExtra("description", selectedProduct.getDescription());
                    startActivity(intent);

                }
            }
        });

        editsearch.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.e("SELECTED", products.get(position).getName());
                Product product = (Product) spinnerAdapterProductName.getItem(position);//listeSecondaireCentreVote.get(position);
                selectedProduct = product;
                Intent intent = new Intent(getApplicationContext(), StationListByProduct.class);
                intent.putExtra("productid", selectedProduct.getProductid());
                intent.putExtra("name", selectedProduct.getName());
                intent.putExtra("description", selectedProduct.getDescription());
                startActivity(intent);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        String url = Util.BASE_URL + "products";
        product_loader.setVisibility(View.VISIBLE);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("response");
                            products = new ArrayList<>();

                            for (int i = 0; i<jsonArray.length(); i++){
                                try {
                                JSONObject productJson = jsonArray.getJSONObject(i);
                                Product product = new Product(
                                        productJson.getInt("id"),
                                        productJson.getString("productid"),
                                        productJson.getString("name"),
                                        productJson.getString("description"),
                                        productJson.getString("type"),
                                        productJson.getString("logo"),
                                        productJson.getDouble("price")
                                );
                                products.add(product);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }

                            productAdapter = new ProductAdapter(ProductList.this, products);
                            product_list.setAdapter(productAdapter);
                            productAdapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        product_loader.setVisibility(View.GONE);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley", error.toString());
                        product_loader.setVisibility(View.GONE);
                    }
                });

// Access the RequestQueue through your singleton class.
        ImgController.getInstance().addToRequestQueue(jsonObjectRequest);


    }

    /*private class GetAllProduct extends AsyncTask<String, Integer, String> {
        private ProgressBar loadingContent;
        private Context context;

        public GetAllProduct(Context context, ProgressBar loadingContent) {
            this.context = context;
            this.loadingContent = loadingContent;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.loadingContent.setVisibility(View.VISIBLE);
            //mClusterManager.clearItems();
            //Log.e("geting agences", "getting agences");
        }

        @Override
        protected String doInBackground(String... strings) {
            String resultat = "";
            String url_string = strings[0];
            URL url = null;
            try {
                url = new URL(url_string);
                HttpURLConnection urlConnection;
                try {
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setDoInput(true);

                    InputStream in = urlConnection.getInputStream();
                    BufferedReader br = null;
                    StringBuilder sb = new StringBuilder();
                    String line;
                    try {
                        br = new BufferedReader(new InputStreamReader(in));
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }

                    } catch (IOException e) {
                        return e.getMessage();
                    } finally {
                        if (br != null) {
                            try {
                                br.close();
                            } catch (IOException e) {
                                return e.getMessage();
                            }
                        }
                    }
                    in.close();
                    //os.close();
                    resultat = sb.toString();

                } catch (IOException e) {
                    return e.getMessage();
                }
            } catch (MalformedURLException e) {
                return e.getMessage();
            }

            return resultat;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (loadingContent.getVisibility() == View.VISIBLE) {
                loadingContent.setVisibility(View.GONE);
            }

            try {
                Util.stations = new ArrayList<Station>();
                JSONObject jsonObject0 = new JSONObject(result);

                Util.avgLatitude = 0;
                Util.avgLongitude = 0;

                if (jsonObject0.getInt("success") == 1 && jsonObject0.getInt("faillure") == 0){
                    JSONArray jsonArray = jsonObject0.getJSONArray("response");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                        Station station = new Station(
                                jsonObject.getInt("id"),
                                jsonObject.getString("stationid"),
                                jsonObject.getString("name"),
                                jsonObject.getString("description"),
                                jsonObject.getString("region"),
                                jsonObject.getString("division"),
                                jsonObject.getString("subdivision"),
                                jsonObject.getString("quarter"),
                                jsonObject.getDouble("latitude"),
                                jsonObject.getDouble("longitude"), null
                        );
                        Util.stations.add(station);
                        Util.avgLatitude += jsonObject.getDouble("latitude");
                        Util.avgLongitude+= jsonObject.getDouble("longitude");

                    }
                    long size = (Util.stations.size()==0)?1:Util.stations.size();
                    Util.avgLatitude = Util.avgLatitude/size;
                    Util.avgLongitude = Util.avgLongitude/size;
                }else{
                    Toast.makeText(getApplicationContext(), "Failled to get data 1", Toast.LENGTH_LONG).show();
                }


            } catch (JSONException e) {
                Log.e("ERROORRRO", e.getMessage());
                Toast.makeText(getApplicationContext(), "Failled to get data 2 " + e.getMessage(), Toast.LENGTH_LONG).show();
            }


            Log.e("RESULT RESULT", result);
        }
    }*/

}
