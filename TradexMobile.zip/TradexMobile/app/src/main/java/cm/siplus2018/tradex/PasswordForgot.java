package cm.siplus2018.tradex;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cm.siplus2018.tradex.utils.Util;

public class PasswordForgot extends AppCompatActivity implements View.OnClickListener {

    private EditText edit_username;
    private Button resetpwdBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_forgot);

        long year =  Calendar.getInstance().get(Calendar.YEAR);
        String copyright =  String.format(getResources().getString(R.string.copyright), year);
        TextView tvCopyRight = findViewById(R.id.copyright);
        tvCopyRight.setText(copyright);

        edit_username = findViewById(R.id.edit_username);
        resetpwdBtn = findViewById(R.id.resetpwdBtn);
        resetpwdBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.resetpwdBtn:
                checkValidation();
                break;
            case R.id.forgot_password:
                // Replace forgot password fragment with animation
                break;
        }
    }

    private void checkValidation() {
        // Get email id and password
        String username = edit_username.getText().toString().trim();
        // Check patter for email id
        Pattern p = Pattern.compile(Util.REGEX_EMAIL);

        Matcher m = p.matcher(username);

        // Check for both field is empty or not
        if (username.equals("") || username.length() == 0 ) {
            //loginLayout.startAnimation(shakeAnimation);
            Toast.makeText(this, "Champ Obligatoire", Toast.LENGTH_LONG).show();
        }
        // Check if email id is valid or not
        else if (!m.matches()) {
            Toast.makeText(getApplicationContext(), "E-Mail Invalide", Toast.LENGTH_LONG).show();
        }

        // Else do login and do your stuff
        else {
            //Toast.makeText(getApplicationContext(), "Do Login.", Toast.LENGTH_LONG).show();

            ProgressBar progressBar = findViewById(R.id.reqresetpwd_progrees_bar);
            progressBar.setVisibility(View.GONE);

            DoResetRequestPwd doResetRequestPwd = new DoResetRequestPwd(this, progressBar, username);
            doResetRequestPwd.execute(Util.BASE_URL + "recover", "email=" + username);
        }


    }


    private class DoResetRequestPwd extends AsyncTask<String,Integer, String> {
        private ProgressBar dialog;
        private Context context;
        private int code;
        private String username;
        public DoResetRequestPwd(Context context, ProgressBar dialog, String username) {
            this.username = username;
            this.context = context;
            this.dialog = dialog;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.dialog.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... strings) {
            String resultat = "";
            String string_url = strings[0];
            String query = strings[1];

            Log.e("URL", string_url + "    |||| " + query);
            URL url = null;
            try {
                url = new URL(string_url);
                HttpURLConnection urlConnection;
                try {
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("POST");
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);
                    OutputStream os = urlConnection.getOutputStream();
                    OutputStreamWriter out = new OutputStreamWriter(os);
                    out.write(query);
                    out.close();
                    code = urlConnection.getResponseCode();
                    if(code == 200){
                        InputStream in = urlConnection.getInputStream();
                        BufferedReader br = null;
                        StringBuilder sb = new StringBuilder();
                        String line;
                        try {
                            br = new BufferedReader(new InputStreamReader(in));
                            while ((line = br.readLine()) != null) {
                                sb.append(line);
                            }

                        } catch (IOException e) {
                            return  "Failed";
                        } finally {
                            if (br != null) {
                                try {
                                    br.close();
                                } catch (IOException e) {
                                    return  "Failed";
                                }
                            }
                        }
                        in.close();
                        //os.close();
                        resultat = sb.toString();
                    }else{
                        return  "Failed";
                    }
                } catch (IOException e) {
                    return  "Failed";
                }
            } catch (MalformedURLException e) {
                return  "Failed";
            }

            return resultat;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute( result);
            if (dialog.getVisibility() == View.VISIBLE) {
                dialog.setVisibility(View.GONE);
            }

            Log.e("RESULTATO", result);
            TextView resultrequestresetpwd =  findViewById(R.id.resultrequestresetpwd);

            if (!result.equals("Failed")){

                try {
                    //JSONArray jsonArray = new JSONArray(result);
                    JSONObject jsonObject = new JSONObject(result);
                    boolean success = jsonObject.getBoolean("success");

                    if (success){
                        JSONObject data = jsonObject.getJSONObject("data");
                        resultrequestresetpwd.setText(data.getString("message"));
                        resultrequestresetpwd.setTextColor(Color.GREEN);

                    }else{
                        JSONObject  error = jsonObject.getJSONObject("error");

                        resultrequestresetpwd.setText(error.getString("message"));
                        resultrequestresetpwd.setTextColor(Color.RED);
                    }

                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                    resultrequestresetpwd.setText(e.getMessage());
                    resultrequestresetpwd.setTextColor(Color.RED);
                }

            }else {

                resultrequestresetpwd.setText("ERROR: code : " + code);
                resultrequestresetpwd.setTextColor(Color.RED);

            }
        }
    }

}
