package cm.siplus2018.tradex;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.Calendar;

public class ContactUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        long year =  Calendar.getInstance().get(Calendar.YEAR);
        String copyright =  String.format(getResources().getString(R.string.copyright), year);
        TextView tvCopyRight = findViewById(R.id.copyright);
        tvCopyRight.setText(copyright);
    }
}
