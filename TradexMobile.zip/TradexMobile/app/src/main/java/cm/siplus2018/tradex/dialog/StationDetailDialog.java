package cm.siplus2018.tradex.dialog;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.toolbox.NetworkImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import cm.siplus2018.tradex.ImgController;
import cm.siplus2018.tradex.R;
import cm.siplus2018.tradex.StationDetailActivity;
import cm.siplus2018.tradex.model.Station;
import cm.siplus2018.tradex.utils.Util;


public class StationDetailDialog extends DialogFragment {
    private StationDetailDialog this_station_detail_dialog;
    private static Station station;
    /**
     * Create a new instance of MyDialogFragment, providing "num"
     * as an argument.
     */
    public static StationDetailDialog newInstance(Station stat, int num) {
        StationDetailDialog f = new StationDetailDialog();

        station = stat;
        // Supply num input as an argument.
        Bundle args = new Bundle();
        args.putInt("num", num);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this_station_detail_dialog = this;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        String titre = "Voir les details de la station " + station.getName();
    	getDialog().setTitle(titre);
        final View fragment_dialog = inflater.inflate(R.layout.station_detail_dialog, container, false);
        TextView goto_station_detail = fragment_dialog.findViewById(R.id.goto_station_detail);
        goto_station_detail.setText(titre);
        Button button_cancel = (Button)fragment_dialog.findViewById(R.id.cancel);
        button_cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				this_station_detail_dialog.dismiss();
			}
		});

        Button button_yes = (Button)fragment_dialog.findViewById(R.id.confirm);
        button_yes.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                this_station_detail_dialog.dismiss();
                Intent intent = new Intent(getActivity(), StationDetailActivity.class);
                intent.putExtra("id", station.getId());
                intent.putExtra("stationid", station.getStationid());
                intent.putExtra("name", station.getName());
                intent.putExtra("latitude", station.getLatitude());
                intent.putExtra("longitude", station.getLongitude());
                getActivity().startActivity(intent);
            }
        });
        //ImageView station_image = fragment_dialog.findViewById(R.id.station_image);
        ProgressBar progress_station_image = fragment_dialog.findViewById(R.id.progress_station_image);
        NetworkImageView imageView = fragment_dialog.findViewById(R.id.station_image);

        //DownloadImageTask downloadImageTask = new DownloadImageTask(station_image, progress_station_image);
        //downloadImageTask.execute(Util.BASE_URL + "stations/" + station.getStationid() + "/image0");

        progress_station_image.setVisibility(View.VISIBLE);
        imageView.setDefaultImageResId(R.drawable.loader_voley);
        imageView.setImageUrl(Util.BASE_URL + "stations/" + station.getStationid() + "/image0", ImgController.getInstance().getImageLoader());
        progress_station_image.setVisibility(View.GONE);

        //DownloadImageTaskOnUi downloadImageTaskOnUi = new DownloadImageTaskOnUi(progress_station_image, imageView);
        //downloadImageTaskOnUi.execute(Util.BASE_URL + "stations/" + station.getStationid() + "/image0");

        return fragment_dialog;
    }


    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;
        ProgressBar progressBar;
        private int statusCode;

        public DownloadImageTask(ImageView bmImage, ProgressBar progressBar) {
            this.bmImage = bmImage;
            this.progressBar = progressBar;//findViewById(R.id.id_image_loader);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.progressBar.setVisibility(View.VISIBLE);
            this.bmImage.setVisibility(View.GONE);
        }


        @Override
        protected Bitmap doInBackground(String... strings) {
            String resultat = "";
            String str_url = strings[0];
            Bitmap bmp = null;
            URL url = null;
            try {
                url = new URL(str_url);
                HttpURLConnection urlConnection;
                try {
                    Log.e("URL", str_url);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setDoInput(true);
                    this.statusCode = urlConnection.getResponseCode();
                    Log.e("statusCode", "4: " + statusCode);
                    InputStream in = urlConnection.getInputStream();
                    bmp = BitmapFactory.decodeStream(in);

                } catch (IOException e) {
                    //Log.e("Exception2", "2: " + e.getMessage());
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("error", "invalid_credentials");
                        jsonObject.put("message", "something Went wrong");
                    } catch (JSONException e1) {

                    }

                    return bmp;
                }
            } catch (MalformedURLException e) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("error", "Wopp something went wrong");
                    jsonObject.put("message", "Wopp something went wrong");
                    return bmp;
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
                return bmp;
            }

            return bmp;
        }
        @Override
        protected void onPostExecute(Bitmap result) {
            if (result != null){
                bmImage.setVisibility(View.VISIBLE);
                bmImage.setImageBitmap(result);
                //drawer_menu_header_photo.setImageBitmap(result);
            }

            progressBar.setVisibility(View.GONE);


        }
    }

    private class DownloadImageTaskOnUi extends AsyncTask<String, Void, String> {
        private  ProgressBar progressBar;
        private int statusCode;
        private NetworkImageView networkImageView;

        public DownloadImageTaskOnUi(ProgressBar progressBar, NetworkImageView networkImageView) {
            this.progressBar = progressBar;//findViewById(R.id.id_image_loader);
            this.networkImageView = networkImageView;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.progressBar.setVisibility(View.VISIBLE);
            Log.e("Progres bar ", "visible");
        }


        @Override
        protected String doInBackground(String... strings) {
            final String str_url = strings[0];
            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    Log.e("UI thread", "I am the UI thread");
                    networkImageView.setImageUrl(str_url, ImgController.getInstance().getImageLoader());
                }
            });

            return str_url;
        }
        @Override
        protected void onPostExecute(String result) {
            progressBar.setVisibility(View.GONE);
            networkImageView.setImageUrl(result, ImgController.getInstance().getImageLoader());
        }
    }
}

