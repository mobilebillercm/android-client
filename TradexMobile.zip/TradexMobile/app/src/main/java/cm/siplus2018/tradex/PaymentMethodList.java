package cm.siplus2018.tradex;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cm.siplus2018.tradex.adapter.PaymentMethodAdapter;
import cm.siplus2018.tradex.model.PaymentMethod;
import cm.siplus2018.tradex.utils.Util;

public class PaymentMethodList extends AppCompatActivity {

    private Toolbar toolbar;
    private GridView paymentmethodslist;
    private PaymentMethodAdapter paymentMethodAdapter;
    private List<PaymentMethod> paymentMethods;
    private ProgressBar paymentmethods_loader;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_method_list);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.payment_method_list));

        paymentmethodslist = findViewById(R.id.paymentmethodslist);

        paymentmethods_loader = findViewById(R.id.paymentmethods_loader);

        paymentmethodslist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PaymentMethod paymentMethod = paymentMethods.get(position);
                Intent intent = new Intent(getApplicationContext(), StationListByPaymentMethod.class);
                intent.putExtra("paymentmethodid", paymentMethod.getPaymentmethodid());
                intent.putExtra("name", paymentMethod.getName());
                intent.putExtra("description", paymentMethod.getDescription());
                Log.e("result-1", "\n\n" + paymentMethod.getName() + "\n\n");
                startActivity(intent);
            }
        });


        String url = Util.BASE_URL + "paymentmethods";
        paymentmethods_loader.setVisibility(View.VISIBLE);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("response");
                    paymentMethods = new ArrayList<>();
                    for (int i = 0; i<jsonArray.length(); i++){
                        try {
                            JSONObject serviceJson = jsonArray.getJSONObject(i);
                            PaymentMethod paymentMethod = new PaymentMethod(
                                    serviceJson.getInt("id"),
                                    serviceJson.getString("paymentmethodid"),
                                    serviceJson.getString("name"),
                                    serviceJson.getString("description"),
                                    serviceJson.getString("issuer"),
                                    serviceJson.getString("logo"),
                                    serviceJson.getString("type"),
                                    serviceJson.getString("typename"),
                                    serviceJson.getString("typedescription")
                                    );
                            paymentMethods.add(paymentMethod);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    paymentMethodAdapter = new PaymentMethodAdapter(PaymentMethodList.this, paymentMethods);
                    paymentmethodslist.setAdapter(paymentMethodAdapter);
                    paymentMethodAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                paymentmethods_loader.setVisibility(View.GONE);
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                paymentmethods_loader.setVisibility(View.GONE);
            }
        });

// Access the RequestQueue through your singleton class.
        ImgController.getInstance().addToRequestQueue(jsonObjectRequest);
    }
}
