package cm.siplus2018.tradex.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.NetworkImageView;

import java.util.List;

import cm.siplus2018.tradex.ImgController;
import cm.siplus2018.tradex.R;
import cm.siplus2018.tradex.model.Station;
import cm.siplus2018.tradex.utils.Util;

/**
 * Created by nkalla on 01/11/18.
 */

public class StationAdapter extends BaseAdapter {
    private Context context;
    private List<Station> stations;
    private RequestQueue requestQueue;

    public StationAdapter(Context context, List<Station> stations) {
        this.context = context;
        this.stations = stations;
    }

    @Override
    public int getCount() {
        return stations.size();
    }

    @Override
    public Object getItem(int position) {
        return stations.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater li=(LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=li.inflate(R.layout.station_layout, null);
        }

        Station station = stations.get(position);
        NetworkImageView imageView = convertView.findViewById(R.id.image_station);
        imageView.setDefaultImageResId(R.drawable.loader_voley);
        imageView.setImageUrl(Util.BASE_URL + "stations/" + station.getStationid() + "/image0", ImgController.getInstance().getImageLoader());

        /*if (station.getImage() != null){
            imageView.setImageBitmap(station.getImage());
        }else{
            String url ="http://192.168.100.12:8000/api/stations/" + station.getStationid() + "/image0";
            Log.e("INFO_INFO", url + "  " + station.getName());
            final ProgressBar image_loader = convertView.findViewById(R.id.image_loader);

            image_loader.setVisibility(View.VISIBLE);

            if (requestQueue == null) {
                requestQueue = Volley.newRequestQueue(context);
            }
            // Initialize a new ImageRequest
            ImageRequest imageRequest = new ImageRequest(
                    url, // Image URL
                    new Response.Listener<Bitmap>() { // Bitmap listener
                        @Override
                        public void onResponse(Bitmap response) {
                            // Do something with response
                            imageView.setImageBitmap(response);
                            image_loader.setVisibility(View.GONE);
                            station.setImage(response);

                            // Save this downloaded bitmap to internal storage
                            //Uri uri = saveImageToInternalStorage(response);

                            // Display the internal storage saved image to image view
                            //mImageViewInternal.setImageURI(uri);
                        }
                    },
                    0, // Image width
                    0, // Image height
                    ImageView.ScaleType.CENTER_CROP, // Image scale type
                    Bitmap.Config.RGB_565, //Image decode configuration
                    new Response.ErrorListener() { // Error listener
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();
                            image_loader.setVisibility(View.GONE);

                            imageView.setImageResource(R.drawable.fuel_station);

                            Drawable drawable = context.getDrawable(R.drawable.fuel_station);

                            station.setImage(convertToBitmap(drawable, 35, 35));
                        }
                    }
            );
            // Add ImageRequest to the RequestQueue
            requestQueue.add(imageRequest);
        }*/




        TextView station_name = convertView.findViewById(R.id.station_name);
        station_name.setText(station.getName());
        TextView station_description = convertView.findViewById(R.id.station_description);
        station_description.setText(" " + station.getDescription());
        TextView station_quarter = convertView.findViewById(R.id.station_quarter);
        station_quarter.setText(station.getQuarter() + " - " + station.getSubdivision() + " - " +
                station.getDivision() + " - " + station.getRegion());
        return convertView;
    }

    public Bitmap convertToBitmap(Drawable drawable, int widthPixels, int heightPixels) {
        Bitmap mutableBitmap = Bitmap.createBitmap(widthPixels, heightPixels, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(mutableBitmap);
        drawable.setBounds(0, 0, widthPixels, heightPixels);
        drawable.draw(canvas);

        return mutableBitmap;
    }
}
