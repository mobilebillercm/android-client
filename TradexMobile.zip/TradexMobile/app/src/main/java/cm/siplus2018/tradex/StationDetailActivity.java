package cm.siplus2018.tradex;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import cm.siplus2018.tradex.utils.Util;

public class StationDetailActivity extends AppCompatActivity {

    private JSONObject station;
    private String stationid;
    private ProgressBar progress_station_by_id;
    private Toolbar toolbar;
    private Button show_rout_btm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_station_detail);

        stationid = getIntent().getExtras().getString("stationid");
        progress_station_by_id = findViewById(R.id.progress_station_by_id);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getIntent().getExtras().getString("name"));

        NetworkImageView imageView = findViewById(R.id.image_station);

        imageView.setDefaultImageResId(R.drawable.loader_voley);
        imageView.setImageUrl(Util.BASE_URL + "stations/" + stationid + "/image0", ImgController.getInstance().getImageLoader());

        show_rout_btm = findViewById(R.id.show_rout_btm);

        GetStationById getStationById = new GetStationById(this, progress_station_by_id);
        getStationById.execute(Util.BASE_URL + "stations/" + stationid);

    }

    private class GetStationById extends AsyncTask<String, Integer, String> {
        private ProgressBar loadingContent;
        private Context context;

        public GetStationById(Context context, ProgressBar loadingContent) {
            this.context = context;
            this.loadingContent = loadingContent;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.loadingContent.setVisibility(View.VISIBLE);
            //mClusterManager.clearItems();
            //Log.e("geting agences", "getting agences");
        }

        @Override
        protected String doInBackground(String... strings) {
            String resultat = "";
            String url_string = strings[0];
            URL url = null;
            try {
                url = new URL(url_string);
                HttpURLConnection urlConnection;
                try {
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setDoInput(true);

                    InputStream in = urlConnection.getInputStream();
                    BufferedReader br = null;
                    StringBuilder sb = new StringBuilder();
                    String line;
                    try {
                        br = new BufferedReader(new InputStreamReader(in));
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }

                    } catch (IOException e) {
                        return e.getMessage();
                    } finally {
                        if (br != null) {
                            try {
                                br.close();
                            } catch (IOException e) {
                                return e.getMessage();
                            }
                        }
                    }
                    in.close();
                    //os.close();
                    resultat = sb.toString();

                } catch (IOException e) {
                    return e.getMessage();
                }
            } catch (MalformedURLException e) {
                return e.getMessage();
            }

            return resultat;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (loadingContent.getVisibility() == View.VISIBLE) {
                loadingContent.setVisibility(View.GONE);
            }

            try {
                JSONObject jsonObject0 = new JSONObject(result);

                if (jsonObject0.getInt("success") == 1 && jsonObject0.getInt("faillure") == 0){
                    station = jsonObject0.getJSONObject("response");
                    TextView station_name = findViewById(R.id.station_name);
                    station_name.setText(station.getString("name"));

                    TextView station_bp = findViewById(R.id.station_bp);
                    station_bp.setText(station.getString("bp"));

                    TextView station_note = findViewById(R.id.station_note);
                    station_note.setText(" 4");

                    show_rout_btm.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            try {
                                Intent intent = new Intent(getApplicationContext(), RouteTrace.class);
                                intent.putExtra("origin_latitude", Util.latitude);
                                intent.putExtra("origin_longitude", Util.longitude);
                                intent.putExtra("destination_latitude", Double.valueOf(station.getString("latitude")));
                                intent.putExtra("destination_longitude", Double.valueOf(station.getString("longitude")));
                                intent.putExtra("stationname", station.getString("name"));

                                startActivity(intent);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }

                        }
                    });

                    TextView region = findViewById(R.id.region);
                    region.setText(" " + station.getString("region"));


                    TextView division = findViewById(R.id.division);
                    division.setText(" " + station.getString("division"));

                    TextView subdivision = findViewById(R.id.subdivision);
                    subdivision.setText(" " + station.getString("subdivision"));


                    TextView quarter = findViewById(R.id.quarter);
                    quarter.setText(" " + station.getString("quarter"));


                    TextView latitude = findViewById(R.id.latitude);
                    latitude.setText(" " + station.getString("latitude"));


                    TextView longitude = findViewById(R.id.longitude);
                    longitude.setText(" " + station.getString("longitude"));

                    ProgressBar loadpetroleumproduct = findViewById(R.id.loadpetroleumproduct);

                    GetDetailsOfStation detailsOfStation = new GetDetailsOfStation(StationDetailActivity.this, loadpetroleumproduct);
                    detailsOfStation.execute(Util.BASE_URL + "stations/" + station.getString("stationid") + "/details");

                }else{
                    Toast.makeText(getApplicationContext(), "Failled to get data", Toast.LENGTH_LONG).show();
                }


            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failled to get data", Toast.LENGTH_LONG).show();
            }


            Log.e("RESULT RESULT", result);
        }
    }


    private class GetDetailsOfStation extends AsyncTask<String, Integer, String> {
        private ProgressBar loadingContent;
        private Context context;

        public GetDetailsOfStation(Context context, ProgressBar loadingContent) {
            this.context = context;
            this.loadingContent = loadingContent;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.loadingContent.setVisibility(View.VISIBLE);
            //mClusterManager.clearItems();
            //Log.e("geting agences", "getting agences");
        }

        @Override
        protected String doInBackground(String... strings) {
            String resultat = "";
            String url_string = strings[0];
            Log.e("URL", url_string);
            URL url = null;
            try {
                url = new URL(url_string);
                HttpURLConnection urlConnection;
                try {
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setDoInput(true);

                    InputStream in = urlConnection.getInputStream();
                    BufferedReader br = null;
                    StringBuilder sb = new StringBuilder();
                    String line;
                    try {
                        br = new BufferedReader(new InputStreamReader(in));
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }

                    } catch (IOException e) {
                        return e.getMessage();
                    } finally {
                        if (br != null) {
                            try {
                                br.close();
                            } catch (IOException e) {
                                return e.getMessage();
                            }
                        }
                    }
                    in.close();
                    //os.close();
                    resultat = sb.toString();

                } catch (IOException e) {
                    return e.getMessage();
                }
            } catch (MalformedURLException e) {
                return e.getMessage();
            }

            return resultat;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (loadingContent.getVisibility() == View.VISIBLE) {
                loadingContent.setVisibility(View.GONE);
            }

            try {

                JSONObject jsonObject0 = new JSONObject(result);

                if (jsonObject0.getInt("success") == 1 && jsonObject0.getInt("faillure") == 0){
                    JSONObject jsonObject1 = jsonObject0.getJSONObject("response");
                    final JSONArray jsonArray = jsonObject1.getJSONArray("petroleumproducts");

                    final LinearLayout petroleumproducts = findViewById(R.id.petroleumproducts);
                    final LinearLayout[] linearLayout = {null};
                    for (int i=0; i<jsonArray.length(); i++){

                        final int finalI = i;
                        new android.os.Handler().postDelayed(
                                new Runnable() {
                                    public void run() {
                                        if (finalI %3==0){
                                            linearLayout[0] = new LinearLayout(StationDetailActivity.this);
                                            linearLayout[0].setOrientation(LinearLayout.HORIZONTAL);
                                        }

                                        final ImageView imageView = new ImageView(StationDetailActivity.this);


                                        LinearLayout.LayoutParams layoutParams0 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1);

                        /*DownloadImageTask downloadImageTask = new DownloadImageTask(imageView, loadingContent);
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        downloadImageTask.execute("http://192.168.43.71:8000/api/produitpetroliers/" + jsonObject.getString("petroleumproductid") + "/logo");*/

                                        final ProgressBar progressBarpetroleumprod = findViewById(R.id.loadpetroleumproduct);

                                        progressBarpetroleumprod.setVisibility(View.VISIBLE);
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = jsonArray.getJSONObject(finalI);

                                        String url =Util.BASE_URL + "produitpetroliers/" + jsonObject.getString("petroleumproductid") + "/logo";

                                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                                        // Initialize a new ImageRequest
                                        ImageRequest imageRequest = new ImageRequest(
                                                url, // Image URL
                                                new Response.Listener<Bitmap>() { // Bitmap listener
                                                    @Override
                                                    public void onResponse(Bitmap response) {
                                                        // Do something with response
                                                        imageView.setImageBitmap(response);
                                                        progressBarpetroleumprod.setVisibility(View.GONE);

                                                        // Save this downloaded bitmap to internal storage
                                                        //Uri uri = saveImageToInternalStorage(response);

                                                        // Display the internal storage saved image to image view
                                                        //mImageViewInternal.setImageURI(uri);
                                                    }
                                                },
                                                0, // Image width
                                                0, // Image height
                                                ImageView.ScaleType.CENTER_CROP, // Image scale type
                                                Bitmap.Config.RGB_565, //Image decode configuration
                                                new Response.ErrorListener() { // Error listener
                                                    @Override
                                                    public void onErrorResponse(VolleyError error) {
                                                        // Do something with error response
                                                        error.printStackTrace();
                                                        progressBarpetroleumprod.setVisibility(View.GONE);
                                                        // Snackbar.make(mCLayout,"Error",Snackbar.LENGTH_LONG).show();
                                                    }
                                                }
                                        );
                                        // Add ImageRequest to the RequestQueue
                                        requestQueue.add(imageRequest);
                                        //linearLayout.addView(imageView, imageParam);

                                        LinearLayout linearLayout1 = new LinearLayout(StationDetailActivity.this);
                                        linearLayout1.setOrientation(LinearLayout.VERTICAL);
                                        LinearLayout.LayoutParams linearlayoutParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                        linearLayout1.setLayoutParams(linearlayoutParam);
                                        linearLayout1.setPadding(8, 15, 8, 15);

                                        TextView name = new TextView(StationDetailActivity.this);
                                        name.setTypeface(name.getTypeface(), Typeface.BOLD);
                                        name.setText("" + jsonObject.getString("name"));
                                        name.setTextSize(12);

                                        TextView description = new TextView(StationDetailActivity.this);
                                        description.setText("     " + jsonObject.getString("description"));
                                        description.setTextSize(10);

                                        TextView price = new TextView(StationDetailActivity.this);
                                        price.setText("" + jsonObject.getString("price") + " FCFA");
                                        price.setTextSize(17);
                                        price.setTypeface(price.getTypeface(), Typeface.BOLD);
                                        price.setTextColor(Color.rgb(176, 28, 46));

                                        linearLayout1.addView(imageView);
                                        linearLayout1.addView(name);
                                        linearLayout1.addView(description);
                                        linearLayout1.addView(price);
                                        linearLayout[0].addView(linearLayout1, layoutParams0);

                                        if (finalI ==jsonArray.length()-1 ||  finalI %3==2){
                            /*if (i==jsonArray.length()-1){
                                if (i%3==0){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayout.addView(linearLayoutv, linearlayoutParamv);
                                }
                                if (i%3==1){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayout.addView(linearLayoutv, linearlayoutParamv);
                                    linearLayout.addView(linearLayoutv, linearlayoutParamv);

                                }
                            }*/
                                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                                                    (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                            petroleumproducts.addView(linearLayout[0], params);


                                        }
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }

                                        }
                                }, 500);

                    }

                    final JSONArray jsonArrayServices = jsonObject1.getJSONArray("services");

                    final LinearLayout services = findViewById(R.id.services);
                    final LinearLayout[] linearLayoutservices = {null};
                    Log.e("jsonArrayServices" , "" + jsonArrayServices.length());
                    for (int i=0; i<jsonArrayServices.length(); i++){

                        final int finalI = i;
                        new android.os.Handler().postDelayed(
                                new Runnable() {
                                    public void run() {
                                        if (finalI %2==0){
                                            linearLayoutservices[0] = new LinearLayout(StationDetailActivity.this);
                                            linearLayoutservices[0].setOrientation(LinearLayout.HORIZONTAL);
                                        }

                                        final ImageView imageView = new ImageView(StationDetailActivity.this);

                                        LinearLayout.LayoutParams layoutParams0 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1);

                        /*DownloadImageTask downloadImageTask = new DownloadImageTask(imageView, loadingContent);
                        downloadImageTask.execute("http://192.168.43.71:8000/api/services/" + jsonObject.getString("serviceid") + "/logo");*/
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = jsonArrayServices.getJSONObject(finalI);


                                        String url =Util.BASE_URL + "services/" + jsonObject.getString("serviceid") + "/logo";
                                        final ProgressBar progressBar = findViewById(R.id.loadservice);

                                        progressBar.setVisibility(View.VISIBLE);

                                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                                        // Initialize a new ImageRequest
                                        ImageRequest imageRequest = new ImageRequest(
                                                url, // Image URL
                                                new Response.Listener<Bitmap>() { // Bitmap listener
                                                    @Override
                                                    public void onResponse(Bitmap response) {
                                                        // Do something with response
                                                        imageView.setImageBitmap(response);
                                                        progressBar.setVisibility(View.GONE);


                                                        // Save this downloaded bitmap to internal storage
                                                        //Uri uri = saveImageToInternalStorage(response);

                                                        // Display the internal storage saved image to image view
                                                        //mImageViewInternal.setImageURI(uri);
                                                    }
                                                },
                                                0, // Image width
                                                0, // Image height
                                                ImageView.ScaleType.CENTER_CROP, // Image scale type
                                                Bitmap.Config.RGB_565, //Image decode configuration
                                                new Response.ErrorListener() { // Error listener
                                                    @Override
                                                    public void onErrorResponse(VolleyError error) {
                                                        // Do something with error response
                                                        error.printStackTrace();
                                                        progressBar.setVisibility(View.GONE);

                                                        // Snackbar.make(mCLayout,"Error",Snackbar.LENGTH_LONG).show();
                                                    }
                                                }
                                        );
                                        // Add ImageRequest to the RequestQueue
                                        requestQueue.add(imageRequest);
                                        //linearLayout.addView(imageView, imageParam);



                                        LinearLayout linearLayout1 = new LinearLayout(StationDetailActivity.this);
                                        linearLayout1.setOrientation(LinearLayout.VERTICAL);
                                        LinearLayout.LayoutParams linearlayoutParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                        linearLayout1.setLayoutParams(linearlayoutParam);
                                        linearLayout1.setPadding(8, 15, 8, 15);
                                        linearLayout1.setGravity(View.TEXT_ALIGNMENT_GRAVITY);

                                        TextView name = new TextView(StationDetailActivity.this);
                                        name.setTypeface(name.getTypeface(), Typeface.BOLD);
                                        name.setText("" + jsonObject.getString("name"));
                                        name.setTextSize(12);

                                        TextView description = new TextView(StationDetailActivity.this);
                                        description.setText("     " + jsonObject.getString("description"));
                                        description.setTextSize(10);

                                        TextView service_price = new TextView(StationDetailActivity.this);
                                        service_price.setText("" + jsonObject.getString("price") + " FCFA");
                                        service_price.setTextSize(10);
                                        service_price.setTextScaleX(1.3f);
                                        service_price.setTextSize(17);
                                        service_price.setTypeface(service_price.getTypeface(), Typeface.BOLD);
                                        service_price.setTextColor(Color.rgb(176, 28, 46));

                                        linearLayout1.addView(imageView);
                                        linearLayout1.addView(name);
                                        linearLayout1.addView(description);
                                        linearLayout1.addView(service_price);
                                        linearLayoutservices[0].addView(linearLayout1, layoutParams0);

                                        if (finalI ==jsonArrayServices.length()-1 ||  finalI %2==1){
                            /*if (i==jsonArrayServices.length()-1){
                                if (i%3==0){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutservices.addView(linearLayoutv, linearlayoutParamv);
                                }
                                if (i%3==1){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutservices.addView(linearLayoutv, linearlayoutParamv);
                                    //linearLayoutservices.addView(linearLayoutv, linearlayoutParamv);

                                }
                            }*/
                                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                                                    (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                            services.addView(linearLayoutservices[0], params);
                                        }


                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                },
                                500);



                    }


                    final JSONArray jsonArrayLubrifiants = jsonObject1.getJSONArray("lubrifiants");

                    final LinearLayout lubrifiants = findViewById(R.id.lubrifiants);
                    final LinearLayout[] linearLayoutlubrifiants = {null};
                    Log.e("jsonArraylubrifiants" , "" + jsonArrayLubrifiants.length());
                    for (int i=0; i<jsonArrayLubrifiants.length(); i++){

                        final int finalI = i;
                        new android.os.Handler().postDelayed(
                                new Runnable() {
                                    public void run() {
                                        if (finalI %3==0){
                                            linearLayoutlubrifiants[0] = new LinearLayout(StationDetailActivity.this);
                                            linearLayoutlubrifiants[0].setOrientation(LinearLayout.HORIZONTAL);
                                        }

                                        final ImageView imageView = new ImageView(StationDetailActivity.this);
                                        imageView.setMaxHeight(150);
                                        imageView.setMaxWidth(150);
                                        LinearLayout.LayoutParams imgViewParam = new LinearLayout.LayoutParams(100, 100,1);


                                        LinearLayout.LayoutParams layoutParams0 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1);

                                        final ProgressBar progressBar = findViewById(R.id.loadlubrifiants);

                                        progressBar.setVisibility(View.VISIBLE);
                        /*DownloadImageTask downloadImageTask = new DownloadImageTask(imageView, loadingContent);
                        downloadImageTask.execute("http://192.168.43.71:8000/api/services/" + jsonObject.getString("serviceid") + "/logo");*/
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = jsonArrayLubrifiants.getJSONObject(finalI);


                                        String url =Util.BASE_URL + "lubrifiants/" + jsonObject.getString("lubrifiantid") + "/logo";

                                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                                        // Initialize a new ImageRequest
                                        ImageRequest imageRequest = new ImageRequest(
                                                url, // Image URL
                                                new Response.Listener<Bitmap>() { // Bitmap listener
                                                    @Override
                                                    public void onResponse(Bitmap response) {
                                                        // Do something with response
                                                        imageView.setImageBitmap(response);
                                                        progressBar.setVisibility(View.GONE);

                                                        // Save this downloaded bitmap to internal storage
                                                        //Uri uri = saveImageToInternalStorage(response);

                                                        // Display the internal storage saved image to image view
                                                        //mImageViewInternal.setImageURI(uri);
                                                    }
                                                },
                                                0, // Image width
                                                0, // Image height
                                                ImageView.ScaleType.CENTER_CROP, // Image scale type
                                                Bitmap.Config.RGB_565, //Image decode configuration
                                                new Response.ErrorListener() { // Error listener
                                                    @Override
                                                    public void onErrorResponse(VolleyError error) {
                                                        // Do something with error response
                                                        error.printStackTrace();
                                                        progressBar.setVisibility(View.GONE);

                                                        // Snackbar.make(mCLayout,"Error",Snackbar.LENGTH_LONG).show();
                                                    }
                                                }
                                        );
                                        // Add ImageRequest to the RequestQueue
                                        requestQueue.add(imageRequest);
                                        //linearLayout.addView(imageView, imageParam);



                                        LinearLayout linearLayout1 = new LinearLayout(StationDetailActivity.this);
                                        linearLayout1.setOrientation(LinearLayout.VERTICAL);
                                        LinearLayout.LayoutParams linearlayoutParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                        linearLayout1.setLayoutParams(linearlayoutParam);
                                        linearLayout1.setPadding(8, 15, 8, 15);
                                        linearLayout1.setGravity(View.TEXT_ALIGNMENT_GRAVITY);

                                        TextView name = new TextView(StationDetailActivity.this);
                                        name.setTypeface(name.getTypeface(), Typeface.BOLD);
                                        name.setText("" + jsonObject.getString("name"));
                                        name.setTextSize(12);

                                        TextView description = new TextView(StationDetailActivity.this);
                                        description.setText("     " + jsonObject.getString("description"));
                                        description.setTextSize(10);

                                        TextView service_price = new TextView(StationDetailActivity.this);
                                        service_price.setText("" + jsonObject.getString("price") +  " FCFA");
                                        service_price.setTextSize(10);
                                        service_price.setTextScaleX(1.3f);
                                        service_price.setTextSize(17);
                                        service_price.setTypeface(service_price.getTypeface(), Typeface.BOLD);
                                        service_price.setTextColor(Color.rgb(176, 28, 46));

                                        linearLayout1.addView(imageView, imgViewParam);
                                        linearLayout1.addView(name);
                                        linearLayout1.addView(description);
                                        linearLayout1.addView(service_price);
                                        linearLayoutlubrifiants[0].addView(linearLayout1, layoutParams0);

                                        if (finalI ==jsonArrayLubrifiants.length()-1 ||  finalI %3==2){
                            /*if (i==jsonArrayLubrifiants.length()-1){
                                if (i%3==0){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutlubrifiants.addView(linearLayoutv, linearlayoutParamv);
                                }
                                if (i%3==1){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutlubrifiants.addView(linearLayoutv, linearlayoutParamv);
                                    //linearLayoutservices.addView(linearLayoutv, linearlayoutParamv);

                                }
                            }*/
                                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                                                    (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                            lubrifiants.addView(linearLayoutlubrifiants[0], params);
                                        }
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                },
                                500);

                    }


                    final JSONArray jsonArrayPaymentmethods = jsonObject1.getJSONArray("paymentmethods");

                    final LinearLayout paymentmethods = findViewById(R.id.paymentmethods);
                    final LinearLayout[] linearLayoutpaymentmethods = {null};
                    Log.e("paymentmethods" , "" + jsonArrayPaymentmethods.length());
                    for (int i=0; i<jsonArrayPaymentmethods.length(); i++){

                        final int finalI = i;
                        new android.os.Handler().postDelayed(
                                new Runnable() {
                                    public void run() {
                                        if (finalI %3==0){
                                            linearLayoutpaymentmethods[0] = new LinearLayout(StationDetailActivity.this);
                                            linearLayoutpaymentmethods[0].setOrientation(LinearLayout.HORIZONTAL);
                                        }

                                        final ImageView imageView = new ImageView(StationDetailActivity.this);
                                        imageView.setMaxHeight(150);
                                        imageView.setMaxWidth(150);
                                        LinearLayout.LayoutParams imgViewParam = new LinearLayout.LayoutParams(100, 100,1);


                                        LinearLayout.LayoutParams layoutParams0 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1);

                        /*DownloadImageTask downloadImageTask = new DownloadImageTask(imageView, loadingContent);
                        downloadImageTask.execute("http://192.168.43.71:8000/api/services/" + jsonObject.getString("serviceid") + "/logo");*/
                                        JSONObject jsonObject = null;
                                        try {
                                            jsonObject = jsonArrayPaymentmethods.getJSONObject(finalI);


                                        String url =Util.BASE_URL + "paymentmethods/" + jsonObject.getString("paymentmethodid") + "/logo";

                                        final ProgressBar progressBar = findViewById(R.id.loadpaymentmethods);

                                        progressBar.setVisibility(View.VISIBLE);

                                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                                        // Initialize a new ImageRequest
                                        ImageRequest imageRequest = new ImageRequest(
                                                url, // Image URL
                                                new Response.Listener<Bitmap>() { // Bitmap listener
                                                    @Override
                                                    public void onResponse(Bitmap response) {
                                                        // Do something with response
                                                        imageView.setImageBitmap(response);
                                                        progressBar.setVisibility(View.GONE);

                                                        // Save this downloaded bitmap to internal storage
                                                        //Uri uri = saveImageToInternalStorage(response);

                                                        // Display the internal storage saved image to image view
                                                        //mImageViewInternal.setImageURI(uri);
                                                    }
                                                },
                                                0, // Image width
                                                0, // Image height
                                                ImageView.ScaleType.CENTER_CROP, // Image scale type
                                                Bitmap.Config.RGB_565, //Image decode configuration
                                                new Response.ErrorListener() { // Error listener
                                                    @Override
                                                    public void onErrorResponse(VolleyError error) {
                                                        // Do something with error response
                                                        error.printStackTrace();
                                                        progressBar.setVisibility(View.GONE);

                                                        // Snackbar.make(mCLayout,"Error",Snackbar.LENGTH_LONG).show();
                                                    }
                                                }
                                        );
                                        // Add ImageRequest to the RequestQueue
                                        requestQueue.add(imageRequest);
                                        //linearLayout.addView(imageView, imageParam);



                                        LinearLayout linearLayout1 = new LinearLayout(StationDetailActivity.this);
                                        linearLayout1.setOrientation(LinearLayout.VERTICAL);
                                        LinearLayout.LayoutParams linearlayoutParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                        linearLayout1.setLayoutParams(linearlayoutParam);
                                        linearLayout1.setPadding(8, 15, 8, 15);
                                        linearLayout1.setGravity(View.TEXT_ALIGNMENT_GRAVITY);

                                        TextView name = new TextView(StationDetailActivity.this);
                                        name.setTypeface(name.getTypeface(), Typeface.BOLD);
                                        name.setText("" + jsonObject.getString("name"));
                                        name.setTextSize(12);

                                        TextView description = new TextView(StationDetailActivity.this);
                                        description.setText("     " + jsonObject.getString("description"));
                                        description.setTextSize(10);

                                        TextView service_price = new TextView(StationDetailActivity.this);
                                        service_price.setText("Emetteur: " + jsonObject.getString("issuer"));
                                        service_price.setTextSize(10);
                        /*service_price.setTextScaleX(1.3f);
                        service_price.setTextSize(17);
                        service_price.setTextColor(Color.rgb(0, 200, 0));*/

                                        linearLayout1.addView(imageView, imgViewParam);
                                        linearLayout1.addView(name);
                                        linearLayout1.addView(description);
                                        linearLayout1.addView(service_price);
                                        linearLayoutpaymentmethods[0].addView(linearLayout1, layoutParams0);

                                        if (finalI ==jsonArrayPaymentmethods.length()-1 ||  finalI %3==2){
                            /*if (i==jsonArrayPaymentmethods.length()-1){
                                if (i%3==0){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutpaymentmethods.addView(linearLayoutv, linearlayoutParamv);
                                }
                                if (i%3==1){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutpaymentmethods.addView(linearLayoutv, linearlayoutParamv);
                                    //linearLayoutservices.addView(linearLayoutv, linearlayoutParamv);

                                }
                            }*/
                                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                                                    (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                            paymentmethods.addView(linearLayoutpaymentmethods[0], params);
                                        }

                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                },
                                500);



                    }


                    JSONArray jsonArrayImages = jsonObject1.getJSONArray("images");

                    LinearLayout images = findViewById(R.id.images);
                    LinearLayout linearLayoutimages = null;
                    Log.e("images" , "" + jsonArrayImages.length());
                    for (int i=0; i<jsonArrayImages.length(); i++){
                        if (i%2==0){
                            linearLayoutimages = new LinearLayout(StationDetailActivity.this);
                            linearLayoutimages.setOrientation(LinearLayout.HORIZONTAL);
                        }

                        final ImageView imageView = new ImageView(StationDetailActivity.this);
                        imageView.setMaxHeight(300);
                        imageView.setMaxWidth(300);
                        LinearLayout.LayoutParams imgViewParam = new LinearLayout.LayoutParams(300, 300,1);



                        LinearLayout.LayoutParams layoutParams0 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1);

                        /*DownloadImageTask downloadImageTask = new DownloadImageTask(imageView, loadingContent);
                        downloadImageTask.execute("http://192.168.43.71:8000/api/services/" + jsonObject.getString("serviceid") + "/logo");*/
                        String path = jsonArrayImages.getString(i);

                        String url =Util.BASE_URL + "stations/" + path;
                        final ProgressBar progressBar = findViewById(R.id.loadimages);

                        progressBar.setVisibility(View.VISIBLE);

                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                        // Initialize a new ImageRequest
                        ImageRequest imageRequest = new ImageRequest(
                                url, // Image URL
                                new Response.Listener<Bitmap>() { // Bitmap listener
                                    @Override
                                    public void onResponse(Bitmap response) {
                                        // Do something with response
                                        imageView.setImageBitmap(response);
                                        progressBar.setVisibility(View.GONE);

                                        // Save this downloaded bitmap to internal storage
                                        //Uri uri = saveImageToInternalStorage(response);

                                        // Display the internal storage saved image to image view
                                        //mImageViewInternal.setImageURI(uri);
                                    }
                                },
                                0, // Image width
                                0, // Image height
                                ImageView.ScaleType.CENTER_CROP, // Image scale type
                                Bitmap.Config.RGB_565, //Image decode configuration
                                new Response.ErrorListener() { // Error listener
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        // Do something with error response
                                        error.printStackTrace();
                                        progressBar.setVisibility(View.GONE);

                                        // Snackbar.make(mCLayout,"Error",Snackbar.LENGTH_LONG).show();
                                    }
                                }
                        );
                        // Add ImageRequest to the RequestQueue
                        requestQueue.add(imageRequest);
                        //linearLayout.addView(imageView, imageParam);



                        LinearLayout linearLayout1 = new LinearLayout(StationDetailActivity.this);
                        linearLayout1.setOrientation(LinearLayout.VERTICAL);
                        LinearLayout.LayoutParams linearlayoutParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        linearLayout1.setLayoutParams(linearlayoutParam);
                        linearLayout1.setPadding(8, 15, 8, 15);
                        linearLayout1.setGravity(View.TEXT_ALIGNMENT_GRAVITY);


                        linearLayout1.addView(imageView, imgViewParam);

                        linearLayoutimages.addView(linearLayout1, layoutParams0);

                        if (i==jsonArrayImages.length()-1 ||  i%2==1){
                            //if (i==jsonArrayPaymentmethods.length()-1){
                                /*if (i%2==0){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutimages.addView(linearLayoutv, linearlayoutParamv);
                                }*/
                                /*if (i%2==1){
                                    LinearLayout linearLayoutv = new LinearLayout(StationDetailActivity.this);
                                    linearLayoutv.setOrientation(LinearLayout.VERTICAL);
                                    LinearLayout.LayoutParams linearlayoutParamv = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    linearLayoutv.setLayoutParams(linearlayoutParamv);
                                    linearLayoutv.setPadding(8, 15, 8, 15);
                                    linearLayoutpaymentmethods.addView(linearLayoutv, linearlayoutParamv);
                                    //linearLayoutservices.addView(linearLayoutv, linearlayoutParamv);

                                }*/
                            //}
                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                                    (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            images.addView(linearLayoutimages, params);
                            Log.e("ADDING ADDING", path);
                        }
                    }

                    JSONArray jsonArraycontacts = jsonObject1.getJSONArray("contacts");

                    LinearLayout contacts = findViewById(R.id.contacts);
                    LinearLayout linearLayoutcontacts = null;
                    Log.e("contacts" , "" + jsonArraycontacts.length());
                    for (int i=0; i<jsonArraycontacts.length(); i++){
                            linearLayoutcontacts = new LinearLayout(StationDetailActivity.this);
                            linearLayoutcontacts.setOrientation(LinearLayout.HORIZONTAL);
                        JSONObject jsonObject = jsonArraycontacts.getJSONObject(i);
                        LinearLayout.LayoutParams layoutParams0 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1);


                        LinearLayout linearLayout1 = new LinearLayout(StationDetailActivity.this);
                        linearLayout1.setOrientation(LinearLayout.VERTICAL);
                        LinearLayout.LayoutParams linearlayoutParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        linearLayout1.setLayoutParams(linearlayoutParam);
                        linearLayout1.setPadding(8, 15, 8, 15);
                        linearLayout1.setGravity(View.TEXT_ALIGNMENT_GRAVITY);

                        TextView phones = new TextView(StationDetailActivity.this);
                        phones.setText("Tels: " + (new JSONArray(jsonObject.getString("phones"))).join(", "));
                        phones.setTextSize(12);

                        TextView bp = new TextView(StationDetailActivity.this);
                        bp.setText("BP: " + jsonObject.getString("bp"));
                        bp.setTextSize(12);

                        TextView address = new TextView(StationDetailActivity.this);
                        address.setText("Adresse: " + jsonObject.getString("address"));
                        address.setTextSize(12);
                        TextView quarter = new TextView(StationDetailActivity.this);
                        quarter.setText("Quartier: " + jsonObject.getString("quarter"));
                        quarter.setTextSize(12);
                        /*service_price.setTextScaleX(1.3f);
                        service_price.setTextSize(17);
                        service_price.setTextColor(Color.rgb(0, 200, 0));
                        690317925   671217464
                        */

                        linearLayout1.addView(phones);
                        linearLayout1.addView(bp);
                        linearLayout1.addView(address);
                        linearLayout1.addView(quarter);
                        linearLayoutcontacts.addView(linearLayout1, layoutParams0);


                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                                    (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            contacts.addView(linearLayoutcontacts, params);

                    }

                }else{
                    Toast.makeText(getApplicationContext(), "Fail To Get Data", Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Failled to get data 20202020", Toast.LENGTH_LONG).show();
                Log.e("JSONException", e.getMessage());
            }




            Log.e("RESULT RESULT 202020", result);
        }
    }


    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;
        ProgressBar progressBar;
        private int statusCode;

        public DownloadImageTask(ImageView bmImage, ProgressBar progressBar) {
            this.bmImage = bmImage;
            this.progressBar = progressBar;//findViewById(R.id.id_image_loader);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.progressBar.setVisibility(View.VISIBLE);
            this.bmImage.setVisibility(View.GONE);
        }


        @Override
        protected Bitmap doInBackground(String... strings) {
            String resultat = "";
            String str_url = strings[0];
            Bitmap bmp = null;
            URL url = null;
            try {
                url = new URL(str_url);
                HttpURLConnection urlConnection;
                try {
                    Log.e("URL", str_url);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setDoInput(true);
                    this.statusCode = urlConnection.getResponseCode();
                    Log.e("statusCode", "4: " + statusCode);
                    InputStream in = urlConnection.getInputStream();
                    bmp = BitmapFactory.decodeStream(in);

                } catch (IOException e) {
                    //Log.e("Exception2", "2: " + e.getMessage());
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("error", "invalid_credentials");
                        jsonObject.put("message", "something Went wrong");
                    } catch (JSONException e1) {

                    }

                    return bmp;
                }
            } catch (MalformedURLException e) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("error", "Wopp something went wrong");
                    jsonObject.put("message", "Wopp something went wrong");
                    return bmp;
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
                return bmp;
            }

            return bmp;
        }

        /*@Override
        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap bmp = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();

                bmp = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return bmp;
        }*/
        @Override
        protected void onPostExecute(Bitmap result) {
            if (result != null){
                bmImage.setVisibility(View.VISIBLE);
                bmImage.setImageBitmap(result);
                //drawer_menu_header_photo.setImageBitmap(result);
            }

            progressBar.setVisibility(View.GONE);


        }
    }


}
